# ScoRev E0 — Silver-Standard Convergence Results

Samples analyzed: N = 120

## Headline (engine vs 3-judge consensus)

| Dimension | Spearman ρ | 95% CI | p | MAE | Inter-judge ρ |
|-----------|:----------:|:------:|:--:|:---:|:-------------:|
| security | 0.286 | [0.111, 0.443] | 1.64e-03 | 1.531 | 0.561 |
| complexity | 0.559 | [0.422, 0.672] | 3.77e-11 | 1.242 | 0.647 |
| maintainability | 0.321 | [0.149, 0.473] | 3.75e-04 | 2.328 | 0.394 |

## How to read this

- **Spearman ρ** is the convergence metric (rank agreement).
- **Inter-judge ρ** is the ceiling: engine↔judge cannot exceed what judges achieve among themselves.
- **MAE** is absolute-scale error (0–10).
- Low **security** variance is expected (clean libraries); report it honestly rather than overclaiming security discrimination.

See results_by_category.csv and the figures for the breakdown.