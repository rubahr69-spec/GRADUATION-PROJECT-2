def proc(d, t, f):
    r = []
    for x in d:
        if t == 1:
            r.append(x * 1.1)
        elif t == 2:
            r.append(x * 1.2)
        elif t == 3:
            r.append(x * 1.15)
        else:
            r.append(x)
    if f == 1:
        r.append(d[0] * 1.1)
    elif f == 2:
        r.append(d[0] * 1.2)
    elif f == 3:
        r.append(d[0] * 1.15)
    return r


def calc(a, b, op):
    if op == "add":
        return a + b
    if op == "sub":
        return a - b
    if op == "mul":
        return a * b
    if op == "div":
        return a / b
