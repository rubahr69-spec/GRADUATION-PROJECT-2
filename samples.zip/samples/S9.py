import datetime

def get_data(x, y, z, w, v):
    if x == 1 and y == 2:
        return z
    elif x == 1 and y == 3:
        return w
    elif x == 2 and y == 2:
        return v
    else:
        return None


def format_date(d):
    return str(d.month) + "/" + str(d.day) + "/" + str(d.year)


def validate(items):
    for i in items:
        if i == None:
            return False
    return True
