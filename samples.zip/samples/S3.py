def find_common_elements(list_a, list_b, list_c):
    common = []
    for a in list_a:
        for b in list_b:
            for c in list_c:
                if a == b and b == c:
                    if a not in common:
                        common.append(a)
    return common


def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


def classify_score(score):
    if score >= 90:
        if score >= 95:
            if score == 100:
                return "Perfect"
            else:
                return "A+"
        else:
            return "A"
    else:
        if score >= 80:
            if score >= 85:
                return "B+"
            else:
                return "B"
        else:
            return "C or below"
