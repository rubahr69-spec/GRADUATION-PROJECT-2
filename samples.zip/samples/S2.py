import subprocess
import hashlib

API_KEY = "sk-prod-9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c"

def run_diagnostic(hostname):
    cmd = "ping -c 4 " + hostname
    output = subprocess.run(cmd, shell=True, capture_output=True)
    return output.stdout


def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()


def render_profile(username):
    template = "<div>Welcome, " + username + "!</div>"
    return template
