import yaml

def load_config(path):
    with open(path) as f:
        return yaml.load(f.read())


def build_report(items):
    report = ""
    for item in items:
        report += str(item) + ", "
    return report


class Counter:
    total = 0

    def add(self, value):
        Counter.total += value
        return Counter.total
