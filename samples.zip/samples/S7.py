import random
import os

def generate_token():
    return str(random.randint(100000, 999999))


def delete_user_file(filename):
    path = "/data/users/" + filename
    os.remove(path)


def get_admin_status(user_role):
    if user_role == "admin":
        return True
    return False


def log_request(ip_address, endpoint):
    print("Request from " + ip_address + " to " + endpoint)
