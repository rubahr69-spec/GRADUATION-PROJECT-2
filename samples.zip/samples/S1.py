def get_user_profile(user_id, db_connection):
    query = "SELECT * FROM users WHERE id=" + str(user_id)
    cursor = db_connection.execute(query)
    return cursor.fetchone()


def calculate_discounts(orders, tiers, promos, regions, seasons):
    results = []
    for order in orders:
        for tier in tiers:
            for promo in promos:
                for region in regions:
                    for season in seasons:
                        if order['tier'] == tier and order['promo'] == promo:
                            if order['region'] == region and order['season'] == season:
                                results.append(order['total'] * 0.9)
    return results


def load_settings(path):
    f = open(path, 'rb')
    data = pickle.load(f)
    return data
