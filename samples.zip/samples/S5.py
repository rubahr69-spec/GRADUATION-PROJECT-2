"""Utility functions for safe arithmetic operations on numeric collections."""

from typing import List


def safe_divide(numerator: float, denominator: float) -> float:
    """Divide two numbers, raising a clear error on division by zero.

    Args:
        numerator: The value to be divided.
        denominator: The value to divide by.

    Returns:
        The result of numerator / denominator.

    Raises:
        ValueError: If denominator is zero.
    """
    if denominator == 0:
        raise ValueError("Cannot divide by zero")
    return numerator / denominator


def filter_positive(values: List[float]) -> List[float]:
    """Return a new list containing only the positive values.

    Args:
        values: A list of numeric values.

    Returns:
        A list containing only the elements greater than zero.
    """
    return [v for v in values if v > 0]
