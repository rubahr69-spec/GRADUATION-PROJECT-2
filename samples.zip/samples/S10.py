"""Helper functions for working with simple text statistics."""

from typing import List


def count_words(text: str) -> int:
    """Count the number of whitespace-separated words in a string.

    Args:
        text: The input text.

    Returns:
        The number of words found.
    """
    return len(text.split())


def average_word_length(words: List[str]) -> float:
    """Compute the average length of a list of words.

    Args:
        words: A non-empty list of word strings.

    Returns:
        The average character length across all words.

    Raises:
        ValueError: If the list is empty.
    """
    if not words:
        raise ValueError("Cannot compute average of an empty list")
    return sum(len(w) for w in words) / len(words)
